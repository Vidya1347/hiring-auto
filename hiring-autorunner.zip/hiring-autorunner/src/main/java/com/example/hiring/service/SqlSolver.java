package com.example.hiring.service;

import org.springframework.stereotype.Component;

@Component
public class SqlSolver {

    // Replace these with your actual final SQL queries for Q1 and Q2
    private static final String SQL_Q1 = "SELECT * FROM table_question1;"; 
    private static final String SQL_Q2 = "SELECT * FROM table_question2;";

    public String solve(String regNo) {
        // Extract digits from regNo
        String digits = regNo.replaceAll("\\D+", "");
        int lastTwo = Integer.parseInt(digits.substring(digits.length() - 2));

        if (lastTwo % 2 == 1) {
            return SQL_Q1; // Odd → Question 1
        } else {
            return SQL_Q2; // Even → Question 2
        }
    }
}
