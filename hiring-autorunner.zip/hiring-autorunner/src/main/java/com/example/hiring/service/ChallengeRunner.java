package com.example.hiring.service;

import com.example.hiring.model.GenerateWebhookRequest;
import com.example.hiring.model.GenerateWebhookResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

@Component
@RequiredArgsConstructor
@Slf4j
public class ChallengeRunner implements ApplicationRunner {

    private final RestTemplate restTemplate;
    private final SqlSolver sqlSolver;

    // values can also be injected from application.yml
    private final String name = "John Doe";
    private final String regNo = "REG12347";
    private final String email = "john@example.com";
    private final String generateUrl = "https://bfhldevapigw.healthrx.co.in/hiring/generateWebhook/JAVA";

    @Override
    public void run(ApplicationArguments args) throws Exception {
        try {
            // Step 1: Call generateWebhook
            GenerateWebhookRequest requestBody = new GenerateWebhookRequest(name, regNo, email);

            ResponseEntity<GenerateWebhookResponse> response =
                    restTemplate.postForEntity(generateUrl, requestBody, GenerateWebhookResponse.class);

            if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
                String webhook = response.getBody().getWebhook();
                String accessToken = response.getBody().getAccessToken();

                log.info("Received webhook: {}", webhook);
                log.info("Received accessToken: {}", accessToken);

                // Step 2: Solve SQL
                String finalQuery = sqlSolver.solve(regNo);
                log.info("Final SQL Query: {}", finalQuery);

                // Step 3: Send finalQuery to webhook
                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.APPLICATION_JSON);
                headers.set("Authorization", accessToken);

                Map<String, String> payload = Map.of("finalQuery", finalQuery);

                HttpEntity<Map<String, String>> entity = new HttpEntity<>(payload, headers);

                ResponseEntity<String> postResponse = restTemplate.postForEntity(webhook, entity, String.class);

                log.info("Webhook POST response: {}", postResponse.getBody());
            } else {
                log.error("Failed to call generateWebhook API: {}", response.getStatusCode());
            }
        } catch (Exception e) {
            log.error("Exception occurred while running challenge", e);
        }
    }
}
